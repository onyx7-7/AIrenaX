import 'package:flutter/material.dart';
import 'package:ai_renax_app/services/api_service.dart';
import 'package:ai_renax_app/models/venue.dart';
import 'package:ai_renax_app/widgets/venue_card.dart';
import 'package:ai_renax_app/screens/venue_details_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  List<Venue> _venues = [];
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _fetchVenues();
  }

  Future<void> _fetchVenues() async {
    try {
      final venues = await ApiService.fetchVenues();
      if (mounted) {
        setState(() {
          _venues = venues;
          _isLoading = false;
        });
      }
    } catch (e) {
      if (mounted) {
        setState(() {
          _isLoading = false;
        });
      }
      // Consider showing an error to the user
      debugPrint('Error fetching venues: $e');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Select a Venue')),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : RefreshIndicator(
              onRefresh: _fetchVenues,
              child: ListView.builder(
                itemCount: _venues.length,
                itemBuilder: (context, index) {
                  final venue = _venues[index];
                  return GestureDetector(
                    onTap: () => Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (_) => VenueDetailsScreen(venue: venue),
                      ),
                    ),
                    child: VenueCard(venue: venue),
                  );
                },
              ),
            ),
    );
  }
}
