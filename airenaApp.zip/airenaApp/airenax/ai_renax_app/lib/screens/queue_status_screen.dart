import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../services/api_service.dart';

class QueueStatusScreen extends StatefulWidget {
  final int venueId;

  const QueueStatusScreen({super.key, required this.venueId});

  @override
  State<QueueStatusScreen> createState() => _QueueStatusScreenState();
}

class _QueueStatusScreenState extends State<QueueStatusScreen> {
  int? position;
  int? peopleAhead;
  int? estimatedWait;
  String? message;
  bool loading = true;

  @override
  void initState() {
    super.initState();
    _loadQueueStatus();
  }

  Future<void> _loadQueueStatus() async {
    final prefs = await SharedPreferences.getInstance();
    final userId = prefs.getInt("user_id");
    if (userId == null) return;

    final status = await ApiService.fetchQueueStatus(userId, widget.venueId);
    setState(() {
      loading = false;
      if (status != null) {
        position = status['position'];
        peopleAhead = status['people_ahead'];
        estimatedWait = status['estimated_wait_minutes'];
      } else {
        message = "You're not in the queue.";
      }
    });
  }

  Future<void> _leaveQueue() async {
    final prefs = await SharedPreferences.getInstance();
    final userId = prefs.getInt("user_id");
    if (userId == null) return;

    final success = await ApiService.leaveQueue(userId, widget.venueId);
    setState(() {
      message = success ? "You have left the queue." : "Failed to leave the queue.";
      position = null;
      peopleAhead = null;
      estimatedWait = null;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Queue Status")),
      body: Center(
        child: loading
            ? const CircularProgressIndicator()
            : Padding(
                padding: const EdgeInsets.all(20),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    if (message != null)
                      Text(message!, style: const TextStyle(color: Colors.amberAccent, fontSize: 18)),
                    if (position != null) ...[
                      Text("Your Position: $position", style: const TextStyle(fontSize: 20)),
                      Text("People Ahead: $peopleAhead"),
                      Text("Estimated Wait: $estimatedWait min"),
                      const SizedBox(height: 20),
                      ElevatedButton(
                        onPressed: _leaveQueue,
                        child: const Text("Leave Queue"),
                      )
                    ]
                  ],
                ),
              ),
      ),
    );
  }
}
