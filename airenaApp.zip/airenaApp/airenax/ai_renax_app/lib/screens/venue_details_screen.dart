import 'package:flutter/material.dart';
import 'package:ai_renax_app/services/api_service.dart';
import 'package:ai_renax_app/models/venue.dart';
import 'package:ai_renax_app/models/menu_item.dart';

class VenueDetailsScreen extends StatefulWidget {
  final Venue venue;

  const VenueDetailsScreen({super.key, required this.venue});

  @override
  State<VenueDetailsScreen> createState() => _VenueDetailsScreenState();
}

class _VenueDetailsScreenState extends State<VenueDetailsScreen> {
  List<MenuItem> _menuItems = [];
  bool _loading = true;
  bool _joining = false;
  String? _message;

  @override
  void initState() {
    super.initState();
    _fetchMenuItems();
  }

  void _fetchMenuItems() async {
    final items = await ApiService.fetchMenuItems(widget.venue.id);
    setState(() {
      _menuItems = items;
      _loading = false;
    });
  }

  void _joinQueue() async {
    setState(() {
      _joining = true;
      _message = null;
    });

    final success = await ApiService.joinQueue(widget.venue.id);
    setState(() {
      _joining = false;
      _message = success ? "You joined the queue!" : "Failed to join the queue.";
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(widget.venue.name)),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : Column(
              children: [
                Expanded(
                  child: ListView.builder(
                    itemCount: _menuItems.length,
                    itemBuilder: (context, index) {
                      final item = _menuItems[index];
                      return ListTile(
                        leading: item.imageUrl != null
                            ? Image.network(item.imageUrl!, width: 50, height: 50, fit: BoxFit.cover)
                            : const Icon(Icons.fastfood),
                        title: Text(item.name),
                        subtitle: Text("\$${item.price.toStringAsFixed(2)}"),
                      );
                    },
                  ),
                ),
                if (_message != null)
                  Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Text(_message!, style: TextStyle(color: Colors.greenAccent)),
                  ),
                Padding(
                  padding: const EdgeInsets.all(16.0),
                  child: ElevatedButton(
                    onPressed: _joining ? null : _joinQueue,
                    child: _joining ? const CircularProgressIndicator() : const Text("Join Queue"),
                  ),
                ),
              ],
            ),
    );
  }
}
