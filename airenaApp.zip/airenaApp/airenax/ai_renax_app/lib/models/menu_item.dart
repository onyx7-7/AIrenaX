class MenuItem {
  final int id;
  final String name;
  final double price;
  final String? imageUrl;
  final String category;
  

  MenuItem({
    required this.id,
    required this.name,
    required this.price,
    this.imageUrl,
    required this.category,
  });

  factory MenuItem.fromJson(Map<String, dynamic> json) {
    return MenuItem(
      id: json['id'],
      name: json['name'],
      price: (json['price'] as num).toDouble(),
      imageUrl: json['image_url'],
      category: json['category'],
    );
  }
}
