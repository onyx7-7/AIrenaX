import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import 'package:ai_renax_app/models/menu_item.dart';
import 'package:ai_renax_app/models/venue.dart';

class ApiService {
  static String baseUrl = "http://localhost:5000";

  // Login method
  static Future<bool> login(String email, String password) async {
    try {
      final url = Uri.parse("$baseUrl/login");
      final response = await http.post(
        url,
        headers: {"Content-Type": "application/json"},
        body: jsonEncode({"email": email, "password": password}),
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        final prefs = await SharedPreferences.getInstance();
        await prefs.setString("token", data["token"]);
        await prefs.setInt("user_id", data["user_id"]);
        return true;
      } else {
        throw Exception('Login failed with status code ${response.statusCode}');
      }
    } catch (e) {
      print('Login error: $e');
      return false;
    }
  }

  static Future<bool> signUp(String email, String password, String name) async {
    try {
      final url = Uri.parse("$baseUrl/register"); // Correct endpoint
      final response = await http.post(
        url,
        headers: {
          'Content-Type': 'application/json',
        },
        body: jsonEncode({
          'name': name,
          'email': email,
          'password': password,
        }),
      );

      // Log the response for debugging
      print('Sign-up response: ${response.body}');
      print('Sign-up status code: ${response.statusCode}');

      if (response.statusCode == 201) { // Assuming 201 is the success code for creation
        final data = jsonDecode(response.body);
        final prefs = await SharedPreferences.getInstance();
        await prefs.setString("token", data["token"]);
        await prefs.setInt("user_id", data["user_id"]);
        return true;
      } else {
        throw Exception('Sign-up failed with status code ${response.statusCode}');
      }
    } catch (e) {
      print('Sign-up error: $e');
      return false;
    }
  }


  // Fetch menu items
  static Future<List<MenuItem>> fetchMenuItems(int venueId) async {
    try {
      final url = Uri.parse("$baseUrl/menu_items/$venueId");
      final response = await http.get(url);

      if (response.statusCode == 200) {
        final List data = jsonDecode(response.body);
        return data.map((m) => MenuItem.fromJson(m)).toList();
      } else {
        throw Exception('Failed to fetch menu items: ${response.statusCode}');
      }
    } catch (e) {
      print('Fetch menu items error: $e');
      return [];
    }
  }

  // Join queue
  static Future<bool> joinQueue(int venueId) async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final token = prefs.getString("token");
      if (token == null) {
        throw Exception('Token not found');
      }

      final url = Uri.parse("$baseUrl/join_queue");
      final response = await http.post(
        url,
        headers: {
          "Content-Type": "application/json",
          "Authorization": "Bearer $token",
        },
        body: jsonEncode({"venue_id": venueId}),
      );

      if (response.statusCode == 200) {
        return true;
      } else {
        throw Exception('Failed to join queue: ${response.statusCode}');
      }
    } catch (e) {
      print('Join queue error: $e');
      return false;
    }
  }

  // Fetch queue status
  static Future<Map<String, dynamic>?> fetchQueueStatus(int userId, int venueId) async {
    try {
      final url = Uri.parse("$baseUrl/queue_status/$userId/$venueId");
      final response = await http.get(url);

      if (response.statusCode == 200) {
        return jsonDecode(response.body);
      } else {
        throw Exception('Failed to fetch queue status: ${response.statusCode}');
      }
    } catch (e) {
      print('Fetch queue status error: $e');
      return null;
    }
  }

  // Leave queue
  static Future<bool> leaveQueue(int userId, int venueId) async {
    try {
      final url = Uri.parse("$baseUrl/leave_queue");
      final response = await http.post(
        url,
        headers: {"Content-Type": "application/json"},
        body: jsonEncode({"user_id": userId, "venue_id": venueId}),
      );

      if (response.statusCode == 200) {
        return true;
      } else {
        throw Exception('Failed to leave queue: ${response.statusCode}');
      }
    } catch (e) {
      print('Leave queue error: $e');
      return false;
    }
  }

  // Fetch venues
  static Future<List<Venue>> fetchVenues() async {
    try {
      final url = Uri.parse("$baseUrl/venues");
      final response = await http.get(url);

      if (response.statusCode == 200) {
        final List data = jsonDecode(response.body);
        return data.map((v) => Venue.fromJson(v)).toList();
      } else {
        throw Exception('Failed to fetch venues: ${response.statusCode}');
      }
    } catch (e) {
      print('Fetch venues error: $e');
      return [];
    }
  }

  // Token Refresh Logic (Optional, if your backend supports refreshing tokens)
  static Future<bool> refreshToken() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final token = prefs.getString("token");

      if (token == null) {
        throw Exception('No token found');
      }

      final url = Uri.parse("$baseUrl/refresh_token");
      final response = await http.post(
        url,
        headers: {
          "Content-Type": "application/json",
          "Authorization": "Bearer $token",
        },
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        await prefs.setString("token", data["new_token"]);
        return true;
      } else {
        throw Exception('Failed to refresh token');
      }
    } catch (e) {
      print('Token refresh error: $e');
      return false;
    }
  }
}

