import 'package:flutter/material.dart';

final ThemeData darkPurpleTheme = ThemeData(
  brightness: Brightness.dark,
  scaffoldBackgroundColor: const Color(0xFF1e1e2f),
  primaryColor: const Color(0xFF5D3FD3),
  colorScheme: ColorScheme.dark(
    primary: Color(0xFF5D3FD3),
    secondary: Color(0xFF8c7ae6),
  ),
  textTheme: const TextTheme(
    bodyLarge: TextStyle(color: Color(0xFFE0D9F6)),
    bodyMedium: TextStyle(color: Color(0xFFE0D9F6)),
  ),
);
