import 'package:ai_renax_app/main.dart' as app;
import 'package:flutter_web_plugins/flutter_web_plugins.dart';

void main() {
  setUrlStrategy(PathUrlStrategy());
  app.main();
}
