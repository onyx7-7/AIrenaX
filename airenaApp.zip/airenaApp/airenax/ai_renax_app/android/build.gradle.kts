plugins {
    id("com.android.application")
    id("kotlin-android")
    id("com.google.gms.google-services") // necessary here
}

android {
    namespace = "com.example.ai_renax_app"
    compileSdk = 34  // Explicitly specify SDK version 34 or the one you want to use
    ndkVersion = "23.1.7779620"  // Or use your Flutter NDK version here

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_11
        targetCompatibility = JavaVersion.VERSION_11
    }

    kotlinOptions {
        jvmTarget = JavaVersion.VERSION_11.toString()
    }

    defaultConfig {
        applicationId = "com.example.ai_renax_app"
        minSdk = 21  // You can specify your Flutter minSdk version here too
        targetSdk = 34  // Same here, or pull from Flutter config
        versionCode = 1
        versionName = "1.0.0"
    }

    buildTypes {
        release {
            signingConfig = signingConfigs.getByName("debug")
        }
    }
}

repositories {
    google() // Ensure that Firebase and other dependencies are fetched from Google's repository
    mavenCentral() // Ensure that other dependencies are fetched from Maven Central
}

dependencies {
    implementation(platform("com.google.firebase:firebase-bom:33.12.0"))
    implementation("com.google.firebase:firebase-analytics")
    implementation("com.google.firebase:firebase-auth")
}




