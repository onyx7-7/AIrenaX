const express = require("express");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const db = require("../queueModel");
const router = express.Router();

const JWT_SECRET =onyx0500onyx; // move to env in production

// Login route
router.post("/login", (req, res) => {
  const { email, password } = req.body;
  db.query("SELECT * FROM users WHERE email = ?", [email], async (err, results) => {
    if (err) return res.status(500).send("DB error");
    if (results.length === 0) return res.status(401).send("Invalid credentials");

    const user = results[0];
    const isMatch = await bcrypt.compare(password, user.password);
    if (!isMatch) return res.status(401).send("Invalid credentials");

    const token = jwt.sign({ id: user.id }, JWT_SECRET, { expiresIn: "2h" });
    res.json({ token, username: user.username });
  });
});

module.exports = router;
