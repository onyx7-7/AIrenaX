const express = require("express");
const db = require("../queueModel");
const router = express.Router();

// Add to queue
router.post("/add", (req, res) => {
  const { user_id, item } = req.body;
  db.query(
    "INSERT INTO queues (user_id, item, status) VALUES (?, ?, 'waiting')",
    [user_id, item],
    (err, result) => {
      if (err) return res.status(500).send("DB error");
      res.json({ message: "Added to queue", id: result.insertId });
    }
  );
});

// View active queue
router.get("/user/:userId", (req, res) => {
  const { userId } = req.params;
  db.query(
    "SELECT * FROM queues WHERE user_id = ? AND status = 'waiting'",
    [userId],
    (err, results) => {
      if (err) return res.status(500).send("DB error");
      res.json(results);
    }
  );
});

module.exports = router;
