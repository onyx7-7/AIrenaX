const mysql = require('mysql2/promise');

// You can export a function that accepts a connection
module.exports = (connection) => {
  return {
    // Check if the user is already in the queue
    async isUserInQueue(user_id, venue_id) {
      const [rows] = await connection.execute(
        `SELECT id FROM queues WHERE user_id = ? AND venue_id = ? AND status = 'waiting'`,
        [user_id, venue_id]
      );
      return rows.length > 0;
    },

    // Get current queue length to calculate position
    async getNextPosition(venue_id) {
      const [rows] = await connection.execute(
        `SELECT COUNT(*) AS count FROM queues WHERE venue_id = ? AND status = 'waiting'`,
        [venue_id]
      );
      return rows[0].count + 1;
    },

    // Insert user into the queue (transaction-safe)
    async addToQueue(user_id, venue_id, position) {
      await connection.execute(
        `INSERT INTO queues (user_id, venue_id, position, status) VALUES (?, ?, ?, 'waiting')`,
        [user_id, venue_id, position]
      );
    },
  };
};
