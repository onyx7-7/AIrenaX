// تحميل المكتبات
require('dotenv').config();
const jwt = require('jsonwebtoken');
const bcrypt = require('bcryptjs');
const authenticateToken = require("./authMiddleware");

const express = require("express");
const cors = require("cors");
const bodyParser = require("body-parser");

console.log("JWT_SECRET:", process.env.JWT_SECRET);
console.log("DB_USER:", process.env.DB_USER);
console.log("DB_PASSWORD:", process.env.DB_PASSWORD);
console.log("DB_NAME:", process.env.DB_NAME);

// إعداد التطبيق
const app = express();
app.use(cors());
app.use(bodyParser.json());

// الاتصال بقاعدة البيانات
const mysql = require('mysql2/promise');

// تم تغيير طريقة الاتصال إلى pool بدلاً من await مباشرة
const pool = mysql.createPool({
  host: 'localhost',
  user: process.env.DB_USER || 'root',
  password: process.env.DB_PASSWORD || 'onyx0500',
  database: process.env.DB_NAME || 'airenax',
  waitForConnections: true,
  connectionLimit: 10,
  queueLimit: 0,
});

const createQueueModel = require('./queueModel');
const queueModel = createQueueModel(pool);

// --------------------------------------------
// Routes
// --------------------------------------------

// جلب جميع الأماكن (venues)
app.get("/venues", async (req, res) => {
  try {
    const [result] = await pool.query("SELECT * FROM venues");
    res.json(result);
  } catch (err) {
    console.error("Error fetching venues:", err);
    res.status(500).json({ message: "Database error" });
  }
});

// جلب عناصر القائمة (menu items) لمكان معين
app.get("/menu_items/:venue_id", async (req, res) => {
  const venueId = req.params.venue_id;
  const sql = `
    SELECT id, name, price, image_url, category
    FROM menu_items
    WHERE venue_id = ?`;
  try {
    const [result] = await pool.query(sql, [venueId]);
    res.json(result);
  } catch (err) {
    console.error("Error fetching menu items:", err);
    res.status(500).json({ message: "Database error" });
  }
});

// نظرة عامة على الطابور
app.get("/queue_overview/:venue_id", async (req, res) => {
  const venueId = req.params.venue_id;
  const sql = `
    SELECT COUNT(*) AS waiting_count
    FROM queues
    WHERE venue_id = ? AND status = 'waiting'`;
  try {
    const [result] = await pool.query(sql, [venueId]);
    const waitingCount = result[0].waiting_count;
    const estimatedWait = waitingCount * 2;
    res.json({
      venue_id: venueId,
      waiting_count: waitingCount,
      estimated_wait_minutes: estimatedWait,
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: "Database error" });
  }
});

// الحصول على حالة الطابور للمستخدم
app.get("/queue_status/:user_id/:venue_id", async (req, res) => {
  const { user_id, venue_id } = req.params;

  const userSql = `
    SELECT position
    FROM queues
    WHERE user_id = ? AND venue_id = ? AND status = 'waiting'`;
  try {
    const [userResult] = await pool.query(userSql, [user_id, venue_id]);
    if (userResult.length === 0) {
      return res.status(404).json({ message: "User is not in the queue." });
    }

    const userPosition = userResult[0].position;
    const countSql = `
        SELECT COUNT(*) AS people_ahead
        FROM queues
        WHERE venue_id = ? AND status = 'waiting' AND position < ?`;
    const [countResult] = await pool.query(countSql, [venue_id, userPosition]);
    const peopleAhead = countResult[0].people_ahead;
    const estimatedWait = peopleAhead * 2;

    res.json({
      position: userPosition,
      people_ahead: peopleAhead,
      estimated_wait_minutes: estimatedWait,
    });
  } catch (err) {
    console.error("Error getting queue status:", err);
    res.status(500).json({ message: "Database error" });
  }
});

// مغادرة الطابور
app.post("/leave_queue", async (req, res) => {
  const { user_id, venue_id } = req.body;

  const sql = `
    UPDATE queues
    SET status = 'done'
    WHERE user_id = ? AND venue_id = ? AND status = 'waiting'`;
  try {
    const [result] = await pool.query(sql, [user_id, venue_id]);
    if (result.affectedRows === 0) {
      return res.status(404).json({ message: "User not found in the queue or already left" });
    }

    res.json({ message: "You have left the queue" });
  } catch (err) {
    console.error("Error leaving queue:", err);
    res.status(500).json({ message: "Database error" });
  }
});

// الانضمام للطابور (Join Queue - Protected)
app.post("/join_queue", authenticateToken, async (req, res) => {
  const { venue_id } = req.body;
  const user_id = req.user.user_id;  // From decoded JWT

  if (!user_id || !venue_id) {
    return res.status(400).json({ message: "user_id and venue_id are required" });
  }

  const getPositionSql = `
    SELECT COUNT(*) AS count 
    FROM queues 
    WHERE venue_id = ? AND status = 'waiting'`;
  try {
    const [result] = await pool.query(getPositionSql, [venue_id]);

    const position = result[0].count + 1;

    const insertSql = `
      INSERT INTO queues (user_id, venue_id, position, status)
      VALUES (?, ?, ?, 'waiting')`;
    const [insertResult] = await pool.query(insertSql, [user_id, venue_id, position]);
    res.json({ message: "You have joined the queue!", position });
  } catch (err) {
    console.error("Error joining queue:", err);
    res.status(500).json({ message: "Database error" });
  }
});

// -----------------------------
// User Register Endpoint
// -----------------------------
app.post("/register", async (req, res) => {
  const { name, email, phone, password } = req.body;
  try {
    const [existing] = await pool.query("SELECT * FROM users WHERE email = ?", [email]);
    if (existing.length > 0) {
      return res.status(400).json({ message: "User already exists" });
    }

    // Hash the password using bcrypt
    const hashedPassword = await bcrypt.hash(password, 10); // Salt rounds are set to 10

    const [result] = await pool.query(
      "INSERT INTO users (name, email, phone, password, created_at) VALUES (?, ?, ?, ?, NOW())",
      [name, email, phone, hashedPassword]
    );
    res.status(201).json({ message: "User registered", user_id: result.insertId });
  } catch (err) {
    res.status(500).json({ message: "Registration failed", error: err.message });
  }
});

// -----------------------------
// User Login Endpoint
// -----------------------------
app.post("/login", async (req, res) => {
  const { email, password } = req.body;

  try {
    const [rows] = await pool.query("SELECT * FROM users WHERE email = ?", [email]);
    if (rows.length === 0) {
      return res.status(401).json({ message: "Invalid email" });
    }

    const user = rows[0];

    if (!process.env.JWT_SECRET) {
      return res.status(500).json({ message: "JWT secret is not configured correctly" });
    }

    const isMatch = await bcrypt.compare(password, user.password);
    if (!isMatch) {
      return res.status(401).json({ message: "Invalid password" });
    }

    const token = jwt.sign(
      { user_id: user.id, email: user.email },
      process.env.JWT_SECRET,
      { expiresIn: "3h" }
    );

    res.json({ token, user_id: user.id });
  } catch (err) {
    console.error("Error during login:", err);
    res.status(500).json({ message: "Login failed", error: err.message });
  }
});

// تشغيل الخادم
const PORT = process.env.PORT || 5000;
app.listen(PORT, () => {
  console.log(`The server is running http://localhost:${PORT}`);
});
